package fxsampler;

public interface FXSamplerConfiguration {
	String getSceneStylesheet();
}

/**
 * A package containing the {@link org.controlsfx.control.action.Action} API, as well
 * as the {@link org.controlsfx.control.action.Action} convenience subclass. 
 * Refer to these two classes for the necessary details on what actions are in
 * the JavaFX context.
 */
package org.controlsfx.control.action;
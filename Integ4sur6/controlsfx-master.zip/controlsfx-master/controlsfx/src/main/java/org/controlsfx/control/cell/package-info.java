/**
 * A package containing a number of useful cell-related classes that do not
 * exist in the base JavaFX distribution, many related to the new 
 * {@link org.controlsfx.control.GridView GridView} control offered in 
 * ControlsFX.
 * 
 * @see org.controlsfx.control.GridView
 */
package org.controlsfx.control.cell;